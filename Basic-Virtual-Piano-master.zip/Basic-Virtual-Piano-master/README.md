# Basic-Virtual-Piano
A simple graphical user interfaces application using C++ language. It is pretty much an electronic piano which maps the piano sounds with the keys on the keyboard.
